export class Seller
{
     username:string;
	 password:number;
     companyname:string;
      gstin:number;
	 briefaboutcompany:string;
	 website:string;
	 emailId:string;
     contactnumber:number;
      postaladdress:number

}