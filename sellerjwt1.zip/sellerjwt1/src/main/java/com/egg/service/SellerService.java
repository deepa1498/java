package com.egg.service;

import java.util.List;

import com.egg.model.SellerEntity;


public interface SellerService {

	SellerEntity addSeller(SellerEntity seller);
	SellerEntity updateSeller(SellerEntity seller,Integer id);
	List<SellerEntity> gettAll();
	 SellerEntity getById(Integer id);
	 
	 SellerEntity findOne(String username);
	
	
}
