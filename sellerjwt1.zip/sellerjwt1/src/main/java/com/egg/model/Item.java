package com.egg.model;

import java.io.Serializable;


import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;

import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;


//import com.cts.entity.CategoryEntity;

@Entity
@Table(name="item")
public class Item implements Serializable {
	@Id
	@GeneratedValue( strategy = GenerationType.IDENTITY)
	 private int itemid;
	 private int categoryid;
	 private int subcategoryid;
	// @Column
	 private Double  itemCost;
	 private String itemName;
	 private String itemDescription;
	 private int quantity;
	 private String model;
	 private String manufacturer;
	 
	 public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	@ManyToOne /* (fetch = FetchType.LAZY, optional = false) */
	    @JoinColumn(name = "sellerId", nullable = false)
	    @OnDelete(action = OnDeleteAction.CASCADE)
	 private SellerEntity  seller;
	 
	 
	public int getItemid() {
		return itemid;
	}
	public SellerEntity getSeller() {
		return seller;
	}
	public void setSeller(SellerEntity seller) {
		this.seller = seller;
	}
	public void setItemid(int itemid) {
		this.itemid = itemid;
	}
	public int getCategoryid() {
		return categoryid;
	}
	public void setCategoryid(int categoryid) {
		this.categoryid = categoryid;
	}
	public int getSubcategoryid() {
		return subcategoryid;
	}
	public void setSubcategoryid(int subcategoryid) {
		this.subcategoryid = subcategoryid;
	}
	public Double getItemCost() {
		return itemCost;
	}
	public void setItemCost(Double itemCost) {
		this.itemCost = itemCost;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getItemDescription() {
		return itemDescription;
	}
	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	

	public Item(int itemid, int categoryid, int subcategoryid, Double itemCost, String itemName, String itemDescription,
			int quantity, String model, String manufacturer, SellerEntity seller) {
		super();
		this.itemid = itemid;
		this.categoryid = categoryid;
		this.subcategoryid = subcategoryid;
		this.itemCost = itemCost;
		this.itemName = itemName;
		this.itemDescription = itemDescription;
		this.quantity = quantity;
		this.model = model;
		this.manufacturer = manufacturer;
		this.seller = seller;
	}
	public Item()
	{
		
	}
	
	
}
