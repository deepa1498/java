package com.egg.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="CategoryEntity")
public class CategoryEntity implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int categoryId;
	private String categoryName;
	private String briefDetails;
	public CategoryEntity() {
		
	}
	
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public String getCategoryNmae() {
		return categoryName;
	}
	public void setCategoryNmae(String categoryNmae) {
		this.categoryName = categoryNmae;
	}
	public String getBriefDetails() {
		return briefDetails;
	}
	public void setBriefDetails(String briefDetails) {
		this.briefDetails = briefDetails;
	}
	public CategoryEntity(int categoryId, String categoryName, String briefDetails) {
		super();
		this.categoryId = categoryId;
		this.categoryName = categoryName;
		this.briefDetails = briefDetails;
	}

	@Override
	public String toString() {
		return "CategoryEntity [categoryId=" + categoryId + ", categoryName=" + categoryName + ", briefDetails="
				+ briefDetails + "]";
	}
	
	
	
	

}
