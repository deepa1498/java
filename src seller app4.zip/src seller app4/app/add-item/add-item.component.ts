import { Component, OnInit } from '@angular/core';
import { Seller } from '../Seller';
import { SellerService } from '../seller.service';
import { Item } from '../Item';
import { combineLatest } from 'rxjs';

@Component({
  selector: 'app-add-item',
  templateUrl: './add-item.component.html',
  styleUrls: ['./add-item.component.css']
})
export class AddItemComponent implements OnInit {

  constructor( private dataservice: SellerService) { }



  item:Item =new Item();


  ngOnInit(): void {
  }

  addingItem()
  {
    console.log("add");
    this.dataservice.addItem(this.item).subscribe(item=>{alert("item is added.")});
  }


  onSubmit()
  {
 this.addingItem();
  }
}
