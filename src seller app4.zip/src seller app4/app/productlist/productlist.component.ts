import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { SellerService } from '../seller.service';
import { Item } from '../Item';
import { Router } from '@angular/router';

@Component({
  selector: 'app-productlist',
  templateUrl: './productlist.component.html',
  styleUrls: ['./productlist.component.css']
})
export class ProductlistComponent implements OnInit {

  constructor(private sellerservice:SellerService, private router: Router) { }

  item:Item[];
sellerid:number=1;
  ngOnInit(): void {

    this.reloaditem();
  }

//chhild sending itemid to update-item to update item
  @Output() messageEvent = new EventEmitter<number>();
  sendMessage(id:number) {
    console.log("sendmessage"+id);
    this.messageEvent.emit(id);
    this.router.navigate(['update-item']);
  }
  reloaditem()
  {
    this.sellerservice.getall(this.sellerid).subscribe(item=>this.item=item);
  }

  deleteitem()
  {
this.sellerservice.deleteitem(this.deleteitem).
  }
  itemDetails()
  {


  }
 Update(id:number)
 {
this.router.navigate(['update-item',id])

 }
  
}
