import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { combineLatest } from 'rxjs';
import { SingupComponent } from './singup/singup.component';
import { AddItemComponent } from './add-item/add-item.component';
import { UpdateItemComponent } from './update-item/update-item.component';
import { ProductlistComponent } from './productlist/productlist.component';


const routes: Routes = [
  {path:"singup" ,component:SingupComponent},
  {path:"add-item",component:AddItemComponent},
  {path:'update-item', component:UpdateItemComponent},
  {path:"productlist",component:ProductlistComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
